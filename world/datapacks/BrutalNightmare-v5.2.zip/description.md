
# TODO
+ Add a level system
Level 1 : 80% buff of hard attributes modifiers ; 10% gain armor/weapon for each items slot ; 10% chance to gain a random effect
Level 2 : 90% buff of hard attributes modifiers ; 20% gain armor/weapon for each items slot ; 15% chance to gain a random effect
Level 3 : 100% buff of hard attributes modifiers ; 30% gain armor/weapon for each items slot ; 30% chance to gain a random effect
Level 4 : 100% buff of hard attributes modifiers ; 50% gain armor/weapon for each items slot; 50% chance to gain a random effect ; 35% chance to gain a random ability
Each level 4 has a chance(10%) to become a Mini-boss (100% gain armor/weapon for each items slot ; 100% chance to gain a random effect ; 100% chance to gain a random ability) 
Level 5 : 100% buff of hard attributes modifiers ; 70% gain armor/weapon for each items slot; 65% chance to gain a random effect ; 50% chance to gain a random ability
40% chance to become a Mini-boss

# Mini-boss names
## Necrofell, The Bone Legion Commander
/give @p minecraft:player_head[profile={id:[I;-1951246686,-591112923,-1428195271,-985195159],properties:[{name:"textures",value:"e3RleHR1cmVzOntTS0lOOnt1cmw6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMzE5YTM4ZThhMDE2NjNlM2MzY2I5ZmZjZjNhYjFiNmJiMWJjMmE5ZmZkOTViNDg3ZGMyM2M2NzkzNjJiMjZiNiJ9fX0="}]},minecraft:lore=['{"text":"https://namemc.com/skin/20dab8be25048b51"}']]
/give @p minecraft:player_head{SkullOwner:{Id:[I;-1951246686,-591112923,-1428195271,-985195159],Properties:{textures:[{Value:"e3RleHR1cmVzOntTS0lOOnt1cmw6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMzE5YTM4ZThhMDE2NjNlM2MzY2I5ZmZjZjNhYjFiNmJiMWJjMmE5ZmZkOTViNDg3ZGMyM2M2NzkzNjJiMjZiNiJ9fX0="}]}},display:{Lore:["{\"text\":\"https://namemc.com/skin/20dab8be25048b51\"}"]}}
Models : witherskeleton, idea: A pharaoh?
+ Abilities list
+ 
## Luminara, The Radiant Light Devourer

<!--  -->
/give @p minecraft:player_head[profile={id:[I;-389525084,-587049002,-1183175747,1893294571],properties:[{name:"textures",value:"e3RleHR1cmVzOntTS0lOOnt1cmw6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMmMwNmI4MThiMjA2NzMxNTI4YjdjMzk4OWNkNGYwODU3M2RlYjY1ZDFkY2QyYjM2NjM5MzVhODMyNzE3ZDM0NSJ9fX0="}]},minecraft:lore=['{"text":"https://namemc.com/skin/42eafcf0812826cb"}']]
/give @p minecraft:player_head{SkullOwner:{Id:[I;-389525084,-587049002,-1183175747,1893294571],Properties:{textures:[{Value:"e3RleHR1cmVzOntTS0lOOnt1cmw6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMmMwNmI4MThiMjA2NzMxNTI4YjdjMzk4OWNkNGYwODU3M2RlYjY1ZDFkY2QyYjM2NjM5MzVhODMyNzE3ZDM0NSJ9fX0="}]}},display:{Lore:["{\"text\":\"https://namemc.com/skin/42eafcf0812826cb\"}"]}}

<!--  -->
Models : skeleton, idea: god? 
+ Abilities list
+ Eternal Cube : Create a cube-shaped dimension , fixed size and location. Also any players in dimension will be "detention"-cannot exit, will teleport them back if they try to escape; in the dimension (add a line-particle to point direct in the player. Start at the center of the cube) . The cube will be destroyed when the boss finish or all target failed
> Each 3seconds, 30% for each target in the area to get a bad effect with 5seconds duration
+ The Heavenly Punisher : Summon a 5x5 area randomly in range with red particle, after 3sec, release 4-7 lightning bolt for each target. Each target has 30% chance to become blind for 5seconds
+ The God's Descend : Teleport all target in range to the center of the range, give Slowness effect and Mining Fatigue effect for 4seconds. `Luminara` will slowly fly higher - after 2.5seconds - Any target in the 5x5 of the center will received 15base damage, then dealt 5 base damage each 1.5seconds. Lasts for 10seconds
+ Light Spark : `Luminara` teleport to the center of the dimension, gain 60% damage reduction and then shoot 2-4 `Light Spark` each 1seconds, dealt 2 base damage auto-aim, last for 7-10seconds 
+ The God's Order : 
  + Swap position with a random target, then dealt 5 base damage, 3 base damage after 2seconds
  + Control arrow to shoot at target
  + When `Luminara` < 50% health, Luminara can activate `Order - The Doppelganger` , summon A Husk that have the same armor-weapon with each target
  + When `Luminara` < 25% health, All skills will be activated faster and more often, also regenerate 2.5% health each 1seconds
+ Diedly Spikes : 

<!--  -->
## General
+ Bed cannot skip night anymore
+ All hostile mobs can follow and detect players from far distance & move faster
+ Passive mobs like Cows, Chickens, Sheep or etc... will fight back when player killed one of them
+ More types of jockey & jockey will summon more often
+ If players is swimming - travelling in the ocean, Mobs riding a boat have a chance to summon : Boats Riders can use boat to chase players. Boats Rider can be Zombie,Skeletons,etc...
+ Spider, Phantom and Enderman can become transparent : Which made them more horifying and harder to fight


## Zombie & Husk
+ Zombie & Husk can place block - pillar up to follow its target
+ Zombie & Husk can break block if needed to follow its target
+ Zombie & Husk can throw tnt
+ Prevent zombie from burning in sunlight
+ Zombie & Husk has a new ability, which can make zombie use ender pearl, flint & steel, etc...
+ Zombie & Husk will summon more often

## Skeleton
+ Skeleton can fire an arrow from the sky into its target (Cooldown)
+ Skeleton can swap between bow/sword for far/near target
+ Prevent skeleton from burning in sunlight

## Creeper
+ Creeper can explode even if its target is behind the wall
+ Creeper can shoot snowball : Work perfectly with [CoffeeG's Useful Snowball](https://modrinth.com/datapack/usefulsnowball) mod
+ Creeper can randomly spawn as Powered Creeper
+ Creeper can disguide as Passive mob like Cow, sheep, chicken,etc...

## Spider
+ Spider can shoot web into its target (Cooldown)
## Enderman
+ Enderman can curse its target (Random - Long cooldown) : After a while , the cursed target will be attacked by a NIGHTMARE enderman
+ Enderman can teleport its target (Cooldown)


## Drowned
+ Drowned can pull its target backward (Cooldown)
+ Drowned can curse its target (Random - Long cooldown) : After a short time, the cursed target will be pulled into the ocean

## Blaze
+ Blaze can split into two blazes on death : Splited Blaze can not split anymore
+ Blaze can spawn at overworld


## Silverfish
+ Silverfish can parasite its target (Small Chance) : The parasited target will take damage ~4 heart after ~30sec. Then 2x Parasited Silverfish will summon.

## Phantom
+ Fire Phantom has chances to summon while player is sleeping : Fire Phantom is immune to fire
+ Phantom can pull its target up a high distance and drop it down
+ Fire Phantom will summon normally : Fire Phantom is immune to fire

## Others
+ Slime can shoot slimeball
+ Ghast can shoot multiple fireball
+ Illusioner can randomly spawn
+ Wither Skeleton can slow its nearby target

 
# Mini bosses
## Witch 
+ (Mini boss) Witch can become Master Witch when target is nearby (Small Chance)
  + Master Witch can cast various spells
## Vindicator
+ (Mini boss) Nightmare Vindicator : 'Crying angel'
  +  Nightmare Vindicator cannot be killed and will do nothing when it's freezing. But if any players moving nearby, it will 'unfreeze'. You can stop its moving by looking at ITS EYES. Or place a torch under the statue to make it 'freezing' again. It'll disappear if it got "frozen" by torch 5 times.

